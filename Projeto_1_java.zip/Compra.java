package Usuarios_1;
import java.util.Scanner;
import java.util.Scanner;

public class Compra {
public Double valor;
public String name_title;
	 

	 public void escolheProduto() {
		 System.out.println("digite qual genero vc deseja comprar");
		 Scanner leitura = new Scanner(System.in);
		 name_title = leitura.nextLine();
		switch(name_title) {
		case "Romance":
			System.out.println("voce escolheu comprar romance");
			break;
		// farei um esbo�o maior dos cases como ficcao,fantasia,e classicos...
		}
		  
	 }
	 }



