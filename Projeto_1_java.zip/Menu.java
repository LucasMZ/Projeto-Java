package Usuarios_1;

public class Menu {

	public void menu() {
	System.out.println("|--------------|");	
	System.out.println("|--------------|");
	System.out.println("|--------------|");	
	System.out.println("|--------------|");	
	System.out.println("|---Cadastro---|");	
	}
	public void exibirClassicobr() {
		System.out.println("-----------------------------");
		System.out.println("| 1 - Se��o Classicos Brasileiro|");
		System.out.println("|Dom Casmurro");
		System.out.println("|O Cortico");
		System.out.println("|A Moreninha");
		System.out.println("|Iracema");
		System.out.println("|O Homem que sabia javanes");
		System.out.println("|O Ateneu");
	}
	public void exibirFantasia() {
		System.out.println("-----------------------------");
		System.out.println("| 2 - Se��o Fantasia|");
		System.out.println("|As Cronicas de N�rnia");
		System.out.println("|O Hobbit");
		System.out.println("|Senhor dos An�is");
		System.out.println("|A B�ssola de ouro");
		System.out.println("|Harry Potter");
		System.out.println("|Percy Jackson");
		System.out.println("|Duna");
		System.out.println("-----------------------------");
	}
	public void exibirRomance() {
		System.out.println("| 3 - Se��o Romance|");
		System.out.println("|Os Sofrimentos do Jovem Werther");
		System.out.println("|Eleanor & Park");
		System.out.println("|� assim que acaba");
		System.out.println("|Orgulho e Preconceito");
		System.out.println("|Raz�o e Sensibilidade");
		System.out.println("|Corte de espinhos e rosas");
		System.out.println("|O Amor nos Tempos do C�lera");
	}
	
}
