package Usuarios_1;
import java.util.ArrayList;

public class Loja {
 public ArrayList<Usuario> usuarios = new ArrayList<>();
 public ArrayList<Menu> menu = new ArrayList<>();
 public ArrayList<Compra> vendas = new ArrayList<>();
 public Double valor;
 public String name_title;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	// criacao de objetos
	Loja nLoja = new Loja();
	
	Usuario user = new Usuario();
	
	Menu menu = new Menu();
	
	
	
	
	@SuppressWarnings("unused")
	Compra select = new Compra();
	// criacao de objetos.fim
	
	
	menu.menu();
	user.fazCadastro();
	
	
	 // imprime usuarios
	
	nLoja.usuarios.add(user);
	nLoja.usuarios.get(0).imprime();
	menu.exibirClassicobr();
	menu.exibirFantasia();
	menu.exibirRomance();
	select.escolheProduto();
	}

}
